Marshall Tran
SE 311 
Assignment 2

Notes:
To run part 1, just run the controller class. Sample input.txt file is provided. To configure the pipe and filter system for pt just go into the config properties. Can also change the pipeline in the controller class for desired order.

For part 2, each folder contains a run and compile script. Turn each the compile into an executable and ./compile to compile each module independently. Configure the run files by providing arguments for Search and NoiseWordRemoval for desired keyword and word removal. 
For example in the Search run file, do: java Main Apple
To search for the keyword Apple
And in NoiseWordRemoval do: java Main orange strawberry banana 
To remove the words orange, strawberry, and banana from the repo.

Was unable to figure out to test the components in the unix pipeline for part 2, however the individual components function on their own.
(Google did not provide any help.)