package filters;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class NoiseWordRemoval extends Filter {

    private Set<String> stopWords;
    public NoiseWordRemoval(Set<String> stopWords) {
        this.stopWords = stopWords;
    }

    public String removeWord(String input){
        String[] inputWords = input.split("\n");
        StringBuilder result = new StringBuilder();
        for (String line : inputWords) {
            String[] words = line.split("\\s+");
            StringBuilder output = new StringBuilder();
            for (String word : words) {
                if (!stopWords.contains(word.toLowerCase())) {
                    output.append(word).append(" ");
                }
            }
            result.append(output.toString().trim()).append("\n");
        }
        return result.toString();
    }

    @Override
    public void run() {
        write(removeWord(read()));
    }
}
