import filters.*;

import java.util.HashSet;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        Set<String> stopSet = new HashSet<>();
        for(String line : args){
            stopSet.add(line.toLowerCase());
        }
        new Thread(new NoiseWordRemoval(stopSet)).start();
    }
}