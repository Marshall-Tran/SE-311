package filters;

import java.io.EOFException;
import java.util.ArrayList;
import java.util.List;

public class CircularShift extends Filter{
    public CircularShift () {}

    public String shift(String input){
        String[] list = input.split("\n");
        StringBuilder output = new StringBuilder();

        List<String> shiftedList = new ArrayList<>();
        for (String line : list) {
            String[] words = line.split("\\s");
            for (int i = 0; i < words.length; i++) {
                StringBuilder sb = new StringBuilder();
                for (int j = 0; j < words.length; j++) {
                    sb.append(words[(i + j) % words.length]);
                    sb.append(" ");
                }
                output.append(sb.toString().trim()).append("\n");
            }
        }
        return output.toString();
    }

    @Override
    public void run() {
        write(shift(read()));
    }
}
