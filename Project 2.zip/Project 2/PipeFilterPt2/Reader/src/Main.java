import filters.*;

public class Main {
    public static void main(String[] args) {
        new Thread(new Reader()).start();
    }
}