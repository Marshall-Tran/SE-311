package filters;

import java.io.EOFException;
import java.util.*;

public class Reader extends Filter{

    public Reader() {}

    @Override
    public void run() {
        write(read());
    }
}
