package filters;

public class Writer extends Filter{

    public Writer() {}

    @Override
    public void run() {
        write(read());
    }
}
