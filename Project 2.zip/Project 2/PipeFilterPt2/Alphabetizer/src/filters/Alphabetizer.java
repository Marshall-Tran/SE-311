package filters;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Alphabetizer extends Filter{
    public Alphabetizer() {}

    public String sorter(String input){
        String[] list = input.split("\n");
        StringBuilder output = new StringBuilder();
        List<String> newList = new ArrayList<>();

        for(String line : list){
            newList.add(line);
        }
        Collections.sort(newList);
        for(String line : newList){
            output.append(line).append("\n");
        }

        return output.toString();
    }

    @Override
    public void run() {
        write(sorter(read()));
    }
}
