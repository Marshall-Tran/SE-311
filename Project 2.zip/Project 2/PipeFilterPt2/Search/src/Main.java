import filters.*;

public class Main {
    public static void main(String[] args) {
       String keyword = args[0];
        new Thread(new Search(keyword)).start();
    }
}