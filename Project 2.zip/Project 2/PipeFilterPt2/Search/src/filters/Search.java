package filters;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Search extends Filter{

    private String keyword;
    public Search(String keyword) {
        this.keyword = keyword;
    }

    public String search(String input){
        String[] list = input.split("\n");
        StringBuilder output = new StringBuilder();
        for (String line : list) {
            if (line.contains(keyword)) {
                // Highlight the keyword by wrapping it with asterisks
                String highlightedLine = line.replaceAll(keyword, "*" + keyword + "*");
                output.append(highlightedLine).append("\n");
            }
        }
        if(output.isEmpty()){
            output.append("[" + keyword + "] not found.").append("\n");
        }


        return output.toString();
    }

    @Override
    public void run() {
        write(search(read()));
    }
}
