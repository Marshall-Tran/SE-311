import filters.*;


public class Controller {
	public static void main(String[] args) {
		OptionReader.readOptions();
 
 // At least two filters are needed
    (new Pipeline(
			new CircularShift(),
			new Writer(),
			new Search(),
			new Reader(),
			new Alphabetizer(),
			new NoiseWordRemoval()
		)).run();
	}
}
