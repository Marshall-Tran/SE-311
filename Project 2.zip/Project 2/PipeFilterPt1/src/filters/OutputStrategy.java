package filters;

import java.util.List;

public interface OutputStrategy {
    void printResult(List<String> storage);
}
