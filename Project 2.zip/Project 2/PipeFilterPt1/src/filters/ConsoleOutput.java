package filters;
import java.util.List;

public class ConsoleOutput implements OutputStrategy {

    public ConsoleOutput(){}

    @Override
    public void printResult(List<String> storage) {
        for (String line : storage) {
            System.out.println(line);
        }
    }
}
