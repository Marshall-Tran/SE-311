package filters;
import java.io.EOFException;
import java.util.ArrayList;
import java.util.List;

public class CircularShift extends Filter{
    public CircularShift () {}

    public List<String> shift(List<String> list){
        List<String> shiftedList = new ArrayList<>();
        for (String line : list) {
            String[] words = line.split("\\s");
            for (int i = 0; i < words.length; i++) {
                StringBuilder sb = new StringBuilder();
                for (int j = 0; j < words.length; j++) {
                    sb.append(words[(i + j) % words.length]);
                    sb.append(" ");
                }
                shiftedList.add(sb.toString().trim());
            }
        }
        return shiftedList;
    }

    @Override
    public void run() {
        List<String> storage = new ArrayList<>();

        if(in == null){
            InputStrategy inputObj = (InputStrategy) OptionReader.getObjectFromKey("Input");
            storage = inputObj.takeInput();
            storage = shift(storage);
        } else {
            try{
                String line;
                while ((line = read()) != null){
                    storage.add(line);
                }
            } catch(EOFException e){
                storage = shift(storage);
            }
        }
        if(out == null) {
            OutputStrategy outObj = (OutputStrategy) OptionReader.getObjectFromKey("Output");
            outObj.printResult(storage);
        } else {
            for (String line : storage){
                write(line);
            }
            write(null);
        }
    }
}
