package filters;
import java.io.EOFException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Alphabetizer extends Filter {

    public Alphabetizer () {}

    public List<String> sorter(List<String> storage) {
        List<String> sortedLines = new ArrayList<>();
        Collections.sort(storage);
        for (String line : storage) {
            sortedLines.add(line);
        }
        return sortedLines;
    }

    @Override
    public void run() {
        List<String> storage = new ArrayList<>();

        if(in == null){
            InputStrategy inputObj = (InputStrategy) OptionReader.getObjectFromKey("Input");
            storage = inputObj.takeInput();
            storage = sorter(storage);
        } else {
            try{
                String line;
                while ((line = read()) != null){
                    storage.add(line);
                }
            } catch(EOFException e){
                storage = sorter(storage);
            }
        }
        if(out == null) {
            OutputStrategy outObj = (OutputStrategy) OptionReader.getObjectFromKey("Output");
            outObj.printResult(storage);
        } else {
            for (String line : storage){
                write(line);
            }
            write(null);
        }
    }
}
