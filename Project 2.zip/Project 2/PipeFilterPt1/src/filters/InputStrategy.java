package filters;

import java.util.List;

public interface InputStrategy {
    List<String> takeInput();
}
