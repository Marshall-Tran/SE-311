package filters;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ConsoleInput implements InputStrategy {
    public ConsoleInput(){}

    @Override
    public List<String> takeInput() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the lines of text (press enter twice to finish):");
        List<String> storage = new ArrayList<>();
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            if (line.isEmpty()) {
                break;
            }
            storage.add(line);
        }
        return storage;
    }
}
