package filters;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FileInput implements InputStrategy {
    public FileInput (){}

    @Override
    public List<String> takeInput() {
        String inputFileName = OptionReader.getString("InputFileName");
        try {
            List<String> storage = new ArrayList<>();
            BufferedReader filereader = new BufferedReader(new FileReader("./" + inputFileName));
            String line;
            while ((line = filereader.readLine()) != null) {
                storage.add(line);
            }
            filereader.close();
            return storage;
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}