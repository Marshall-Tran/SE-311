package filters;
import java.io.EOFException;
import java.util.*;

public class Search extends Filter{

    public Search () {}

    public List<String> search(String keyword, List<String> storage) {
        List<String> searchList = new ArrayList<>();
        for (String line : storage) {
            if (line.contains(keyword)) {
                // Highlight the keyword by wrapping it with asterisks
                String highlightedLine = line.replaceAll(keyword, "*" + keyword + "*");
                //System.out.println("Searcher output: " + highlightedLine); // Debug statement
                searchList.add(highlightedLine);
            }
        }
        if(searchList.isEmpty()){
            searchList.add("[" + keyword + "] not found.");
        }
        return searchList;
    }

    @Override
    public void run() {
        List<String> storage = new ArrayList<>();

        if(in == null){
            InputStrategy inputObj = (InputStrategy) OptionReader.getObjectFromKey("Input");
            String keyWord = OptionReader.getString("Keyword");
            storage = inputObj.takeInput();
            storage = search(keyWord, storage);
        } else {
            try{
                String line;
                while ((line = read()) != null){
                    storage.add(line);
                }
            } catch(EOFException e){
                String keyWord = OptionReader.getString("Keyword");
                storage = search(keyWord, storage);
            }
        }
        if(out == null) {
            OutputStrategy outObj = (OutputStrategy) OptionReader.getObjectFromKey("Output");
            outObj.printResult(storage);
        } else {
            for (String line : storage){
                write(line);
            }
            write(null);
        }
    }
}