package filters;

import java.io.EOFException;
import java.util.*;

public class Writer extends Filter{

    public Writer() {}

    @Override
    public void run() {
        List<String> storage = new ArrayList<>();
        if(in == null){
            InputStrategy inputObj = (InputStrategy) OptionReader.getObjectFromKey("Input");
            storage = inputObj.takeInput();
        } else {
            try {
                String line;
                while ((line = read()) != null) {
                    storage.add(line);
                }
            } catch (EOFException e) {
                System.out.println("Writer Done.");
            }
        }
        if(out == null) {
            OutputStrategy outObj = (OutputStrategy) OptionReader.getObjectFromKey("Output");
            outObj.printResult(storage);
        } else {
            for (String line : storage){
                write(line);
            }
            write(null);
        }
    }
}