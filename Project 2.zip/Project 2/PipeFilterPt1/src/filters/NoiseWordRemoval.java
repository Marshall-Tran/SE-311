package filters;

import java.io.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class NoiseWordRemoval extends Filter {

    public NoiseWordRemoval() {}

    public List<String> removeWord(Set<String> stopWords, List<String> storage){
        List<String> removedList = new ArrayList<>();
        for (String line : storage) {
            String[] words = line.split("\\s+");
            StringBuilder output = new StringBuilder();
            for (String word : words) {
                if (!stopWords.contains(word.toLowerCase())) {
                    output.append(word).append(" ");
                }
            }
            removedList.add(output.toString().trim());
        }
        return removedList;
    }

    public Set<String> splitString(String stopWords) {
        String[] words = stopWords.split(", ");
        Set<String> stopSet = new HashSet<>();
        for(String word : words) {
            stopSet.add(word.toLowerCase());
        }
        return stopSet;
    }

    @Override
    public void run() {
        List<String> storage = new ArrayList<>();

        if(in == null){
            InputStrategy inputObj = (InputStrategy) OptionReader.getObjectFromKey("Input");
            String stopWords = OptionReader.getString("Stopwords");
            Set<String> stopSet = splitString(stopWords);
            storage = inputObj.takeInput();
            storage = removeWord(stopSet, storage);
        } else {
            try{
                String line;
                while ((line = read()) != null){
                    storage.add(line);
                }
            } catch(EOFException e){
                String stopWords = OptionReader.getString("Stopwords");
                Set<String> stopSet = splitString(stopWords);
                storage = removeWord(stopSet, storage);
            }
        }
        if(out == null) {
            OutputStrategy outObj = (OutputStrategy) OptionReader.getObjectFromKey("Output");
            outObj.printResult(storage);
        } else {
            for (String line : storage){
                write(line);
            }
            write(null);
        }
    }
}
