Marshall Tran
SE 311 
Assignment 1

How to run:
Just run the controller class to start the program. When entering a text file name, make sure to include the .txt extension. For example type in input.txt if the file name is called input.txt. Sample txt file is included. When entering lines manually, press enter twice to finish inputing to console.
