import java.util.Scanner;

public class ConsoleInput implements InputStrategy {
    public ConsoleInput(){}

    @Override
    public LineStorage takeInput() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the lines of text (press enter twice to finish):");
        LineStorage storage = new LineStorage();
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            if (line.isEmpty()) {
                break;
            }
            storage.addLine(line);
        }
        return storage;
    }
}
