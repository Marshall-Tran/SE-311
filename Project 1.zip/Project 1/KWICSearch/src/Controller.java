import java.util.*;

public class Controller {	
	
	public static void main(String[] args) {
		
		//Get input object
		OptionReader.readOptions();
		InputStrategy inputObj = (InputStrategy) OptionReader.getObjectFromKey("Input");
		LineStorage storageObj = inputObj.takeInput();

		//Get shifter object
		CircularShift shiftObj = (CircularShift) OptionReader.getObjectFromKey("Shifter");
		shiftObj.shift(storageObj);
		
		//Get sorter object
		Alphabetizer sortObj = (Alphabetizer) OptionReader.getObjectFromKey("Sorter");
		sortObj.sorter(storageObj);

		//Get sentence repo output object
		OutputStrategy outputObj = (OutputStrategy) OptionReader.getObjectFromKey("Output");
		outputObj.printResult(storageObj);

		//Get searcher object
		Search searchObj = (Search) OptionReader.getObjectFromKey("Searcher");
		Scanner scanner = new Scanner(System.in);
		System.out.println("\nEnter keyword: ");
		String keyWord = scanner.nextLine();
		searchObj.search(keyWord,storageObj);

		//Get Search Output object
		Output searchOutObj = (Output) OptionReader.getObjectFromKey("SearchOutput");

		String head = OptionReader.getString("Header");
		String foot = OptionReader.getString("Footer");
		boolean needHeader = false;
		boolean needFooter = false;

		if (head.equals("true")) {
			needHeader = true;
		}

		if (foot.equals("true")) {
			needFooter = true;
		}

		if(needHeader && !needFooter){
			Output outputHeader = new Header(searchOutObj);
			outputHeader.printResult(storageObj);

		} else if (!needHeader && needFooter) {
			Output outputFooter = new Footer(searchOutObj);
			outputFooter.printResult(storageObj);

		} else if(needHeader && needFooter){
			Output both = new Footer(new Header(searchOutObj));
			both.printResult(storageObj);
		} else {
			Output notBoth = searchOutObj;
			notBoth.printResult(storageObj);
		}
	}
}