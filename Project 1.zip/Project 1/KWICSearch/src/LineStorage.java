import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class LineStorage implements Serializable, Cloneable {

    private List<String> lines = new ArrayList();

    private List<String> shiftedLines = new ArrayList<>();
    private List<String> sortedLines = new ArrayList<>();
    private List<String> highlightedSortedLines = new ArrayList<>();
    private List<String> highlightedOriginalLines = new ArrayList<>();

    private int highlightedSize = 0;
    private int sortedSize = 0;


    public LineStorage() {}

    protected List<String> getLines() {

        return this.lines;
    }

    protected List<String> getShiftedLines() {

        return this.shiftedLines;
    }

    protected List<String> getSortedLines() {

        return this.sortedLines;
    }

    protected List<String> getHighlightedSortedLines() {
        return this.highlightedSortedLines;
    }

    protected List<String> getHighlightedOriginalLines(){return this.highlightedOriginalLines;}

    protected int getHighlightedSize() {return this.highlightedSize;}

    protected int getSortedSize() {return this.sortedSize;}


    protected void addLine(String line) {
        this.lines.add(line);
    }

    protected void addShiftedLines(String shiftedLine) {
        this.shiftedLines.add(shiftedLine);
    }

    protected void addSortedLines(String sortedLine) {
        this.sortedLines.add(sortedLine);
    }

    protected void addHighlightedSortedLines(String highlightedLine) {

        this.highlightedSortedLines.add(highlightedLine);
    }
    protected void addHighlightedOriginalLines(String highlightedLine) {

        this.highlightedOriginalLines.add(highlightedLine);
    }

    protected void incrementHighlightedSize(){
        this.highlightedSize++;
    }
    protected void incrementSortedSize(){
        this.sortedSize++;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        LineStorage storage = (LineStorage) super.clone();
        storage.lines = new ArrayList<>(lines);
        storage.shiftedLines = new ArrayList<>(shiftedLines);
        storage.sortedLines = new ArrayList<>(sortedLines);
        storage.highlightedSortedLines = new ArrayList<>(highlightedSortedLines);
        storage.highlightedOriginalLines = new ArrayList<>(highlightedOriginalLines);
        return storage;    // return shallow copy
    }
}
