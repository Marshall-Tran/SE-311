public interface InputStrategy {
    LineStorage takeInput();
}
