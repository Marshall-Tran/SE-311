public interface OutputStrategy {
    void printResult(LineStorage storage);
}
