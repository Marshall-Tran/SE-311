public abstract class SearchOutputDecorator implements Output {
    protected Output result;

    public SearchOutputDecorator(Output result) {
        this.result = result;
    }

    public void printResult(LineStorage storage) {result.printResult(storage);}

}