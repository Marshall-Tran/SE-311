
public class Header extends SearchOutputDecorator {
    public Header (Output result) {
        super(result);
    }
    @Override
    public void printResult(LineStorage storage){
        header(storage);
        result.printResult(storage);
    }

    private void header (LineStorage storage){
        System.out.println("\n[" + storage.getHighlightedSize() + "] results are found in [" + storage.getSortedSize() + "] records. \n");
    }
}
