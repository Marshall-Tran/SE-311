import java.io.*;
import java.util.*;

public class SearchOutput implements Output{

    public SearchOutput() {}

    @Override
    public void printResult(LineStorage storage){
        List<String> highlightedOriginal = storage.getHighlightedOriginalLines();
        List<String> highlightedSorted = storage.getHighlightedSortedLines();

        System.out.println("Highlighted keyword lines found in original text:");

        for(String line : highlightedOriginal){
            System.out.println(line);
        }

        System.out.println("\nHighlighted keyword lines found in sorted text:");

        for(String line : highlightedSorted){
            System.out.println(line);
        }
    }
}
