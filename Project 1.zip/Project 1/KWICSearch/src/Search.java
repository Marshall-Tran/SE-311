import java.util.*;

public class Search {

    public Search () {}

    public void search(String keyword, LineStorage storage) {
        List<String> list = storage.getSortedLines();
        for (String line : list) {
            if (line.contains(keyword)) {
                // Highlight the keyword by wrapping it with asterisks
                String highlightedLine = line.replaceAll(keyword, "*" + keyword + "*");
                //System.out.println("Searcher output: " + highlightedLine); // Debug statement
                storage.addHighlightedSortedLines(highlightedLine);
                storage.incrementHighlightedSize();
            }
        }
        if(storage.getHighlightedSortedLines().isEmpty()){
            storage.addHighlightedSortedLines("[" + keyword + "] not found.");
        }

        List<String> originalList = storage.getLines();
        for (String line : originalList) {
            if (line.contains(keyword)) {
                // Highlight the keyword by wrapping it with asterisks
                String highlightedLine = line.replaceAll(keyword, "*" + keyword + "*");
                //System.out.println("Searcher output: " + highlightedLine); // Debug statement
                storage.addHighlightedOriginalLines(highlightedLine);
            }
        }
        if(storage.getHighlightedOriginalLines().isEmpty()){
            storage.addHighlightedOriginalLines("[" + keyword + "] not found.");
        }
    }
}