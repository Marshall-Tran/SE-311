import java.util.List;

public class ConsoleOutput implements OutputStrategy {

    public ConsoleOutput(){}

    @Override
    public void printResult(LineStorage storage) {
        List<String> results = storage.getSortedLines();
        for (String line : results) {
            System.out.println(line);
        }
    }
}
