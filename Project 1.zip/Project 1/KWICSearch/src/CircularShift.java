import java.util.ArrayList;
import java.util.List;

public class CircularShift {

    public CircularShift () {}

    public void shift(LineStorage storage){
        List<String> list = storage.getLines();
        for (String line : list) {
            String[] words = line.split("\\s");
            for (int i = 0; i < words.length; i++) {
                StringBuilder sb = new StringBuilder();
                for (int j = 0; j < words.length; j++) {
                    sb.append(words[(i + j) % words.length]);
                    sb.append(" ");
                }
                storage.addShiftedLines(sb.toString().trim());
            }
        }
    }
}
