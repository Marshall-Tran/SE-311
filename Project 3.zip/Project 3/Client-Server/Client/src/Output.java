public interface Output {
    void printResult(LineStorage storage);
}
