import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Footer extends SearchOutputDecorator {
    public Footer (Output result) {
        super(result);
    }

    @Override
    public void printResult(LineStorage storage){
        result.printResult(storage);
        footer();
    }
    private void footer () {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        String timeString = now.format(timeFormatter);
        String dateString = now.format(dateFormatter);
        System.out.println("\nCurrent Time: " + timeString + " Date is: " +  dateString);
    }
}
