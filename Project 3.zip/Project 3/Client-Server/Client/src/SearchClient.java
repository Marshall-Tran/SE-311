import javax.sound.sampled.Line;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.*;
import java.net.*;

public class SearchClient {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        OptionReader.readOptions();

        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a keyword: ");
        String keyWord = scanner.nextLine();

        Socket socket = new Socket("localhost", 8080);
        ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
        oos.writeObject(keyWord);

        ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
        LineStorage storage = (LineStorage) ois.readObject();

        String head = OptionReader.getString("Header");
        String foot = OptionReader.getString("Footer");

        boolean needHeader = false;
        boolean needFooter = false;



        if (head.equals("true")) {
            needHeader = true;
        }

        if (foot.equals("true")) {
            needFooter = true;
        }

        if(needHeader && !needFooter){
            Output outputHeader = new Header(new SearchOutput());
            outputHeader.printResult(storage);

        } else if (!needHeader && needFooter) {
            Output outputFooter = new Footer(new SearchOutput());
            outputFooter.printResult(storage);

        } else if(needHeader && needFooter){
            Output both = new Footer(new Header(new SearchOutput()));
            both.printResult(storage);
        } else {
            Output notBoth = new SearchOutput();
            notBoth.printResult(storage);
        }
        oos.close();
        socket.close();
    }
}