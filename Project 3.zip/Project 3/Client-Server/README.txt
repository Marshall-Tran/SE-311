Marshall Tran
SE 311
Assignment 3



Notes:

Decorator: SearchOutputDecorator
Component: SearchOutput
Concrete Decorators: Header, Footer

Strategy: InputInterface || OutInterface
Context: Server
Concrete Strategy: FileInput, ConsoleInput || FileOutput, Console Output


How to run: Run Server.java and SearchClient.java. Simply just make multiple instances of SearchClient if you want to have multiple clients that wants to do a search. 

Configuration: There is a config file for both server and client. Config file for client allows you to add header/footer. Config file for server lets you change input and output type (txt file or console).