import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileInput implements InputInterface{
    public FileInput (){}

    @Override
    public LineStorage takeInput() {
        String inputFileName = OptionReader.getString("InputFileName");
        try {
            LineStorage storage = new LineStorage();
            BufferedReader filereader = new BufferedReader(new FileReader("./" + inputFileName));
            String line;
            while ((line = filereader.readLine()) != null) {
                storage.addLine(line);
            }
            filereader.close();
            return storage;
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}