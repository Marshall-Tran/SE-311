import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Alphabetizer {

    public Alphabetizer () {}

    public void sorter(LineStorage storage) {
        List<String> list = storage.getShiftedLines();
        Collections.sort(list);
        for (String line : list) {
            storage.addSortedLines(line);
            storage.incrementSortedSize();
        }
    }
}
