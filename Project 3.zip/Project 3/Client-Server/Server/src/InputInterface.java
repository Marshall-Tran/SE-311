public interface InputInterface {
    LineStorage takeInput();
}
