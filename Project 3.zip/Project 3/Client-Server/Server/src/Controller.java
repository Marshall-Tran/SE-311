

import java.util.*;

public class Controller {	
	
	public static void main(String[] args) {
		
		//Get input object
		
		OptionReader.readOptions();
		InputInterface inputObj = (InputInterface) OptionReader.getObjectFromKey("Input");
		
		LineStorage storageObj = inputObj.takeInput();

		//Get shifter object
		CircularShift shiftObj = (CircularShift) OptionReader.getObjectFromKey("Shifter");
								
		shiftObj.shift(storageObj);
		
		//Get sorter object
		Alphabetizer sortObj = (Alphabetizer) OptionReader.getObjectFromKey("Sorter");
		
		sortObj.sorter(storageObj);

		//Get output object
		OutInterface outputObj = (OutInterface) OptionReader.getObjectFromKey("Output");
		outputObj.printResult(storageObj);

	}
}
