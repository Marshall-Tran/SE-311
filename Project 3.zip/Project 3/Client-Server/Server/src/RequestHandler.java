import javax.sound.sampled.Line;
import java.io.*;
import java.net.*;

public class RequestHandler extends Thread {
    private Socket clientSocket = null;
    private LineStorage storage;
    public RequestHandler(Socket cSocket, LineStorage storage){
        clientSocket = cSocket;
        this.storage = storage;
    }

    public void run(){
        try {
            ObjectInputStream ois = new ObjectInputStream(clientSocket.getInputStream());
            String keyWord  = (String) ois.readObject();

            Search search = new Search();
            search.search(keyWord, storage);

            ObjectOutputStream oos  = new ObjectOutputStream(clientSocket.getOutputStream());
            oos.writeObject(storage);
            clientSocket.close();

        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}
L