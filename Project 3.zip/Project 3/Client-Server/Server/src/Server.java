import java.io.*;
import java.net.*;

public class Server {
    public static void main(String[] args) throws IOException, CloneNotSupportedException {
        ServerSocket server = new ServerSocket(8080);

        //Get input object

        OptionReader.readOptions();
        InputInterface inputObj = (InputInterface) OptionReader.getObjectFromKey("Input");

        LineStorage storageObj = inputObj.takeInput();

        //Get shifter object
        CircularShift shiftObj = (CircularShift) OptionReader.getObjectFromKey("Shifter");

        shiftObj.shift(storageObj);

        //Get sorter object
        Alphabetizer sortObj = (Alphabetizer) OptionReader.getObjectFromKey("Sorter");

        sortObj.sorter(storageObj);

        //Get output object
        OutInterface outputObj = (OutInterface) OptionReader.getObjectFromKey("Output");
        outputObj.printResult(storageObj);

        while (true){
            Socket client = server.accept();
            LineStorage storage = (LineStorage) storageObj.clone();
            RequestHandler rh = new RequestHandler(client, storage);
            rh.start();
        }
    }
}