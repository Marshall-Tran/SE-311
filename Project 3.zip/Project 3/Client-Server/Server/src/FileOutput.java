import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class FileOutput implements OutInterface{

    public FileOutput(){}

    @Override
    public void printResult(LineStorage storage) {
        String fileName = OptionReader.getString("OutputFileName");
        List<String> results = storage.getSortedLines();
        try {
            BufferedWriter fileWriter = new BufferedWriter(new FileWriter(fileName));

            for (String line : results) {
                fileWriter.write(line);
                fileWriter.newLine();
            }
            fileWriter.close();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}