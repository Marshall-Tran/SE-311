public interface OutInterface {
    void printResult(LineStorage storage);
}
