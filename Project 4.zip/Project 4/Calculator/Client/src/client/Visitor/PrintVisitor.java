package client.Visitor;

import client.Composite.*;

public class PrintVisitor implements Visitor{
    @Override
    public String visit(Expression expr) {
        if (expr instanceof OpExpr)
            return visit((OpExpr) expr);
        return visit((AtomExpr) expr);
    }

    @Override
    public String visit(AddSubExpr expr) {
        Expression left = expr.getLeftChild();
        Expression right = expr.getRightChild();
        String leftValue = visit(left);
        String rightValue = visit(right);

        return leftValue + " " + expr.getValue() + " " + rightValue;
    }

    @Override
    public String visit(MulDivExpr expr) {
        Expression left = expr.getLeftChild();
        Expression right = expr.getRightChild();
        String leftValue = visit(left);
        String rightValue = visit(right);

        return leftValue + " " + expr.getValue() + " " + rightValue;
    }

    @Override
    public String visit(AtomExpr expr) {
        return expr.getValue();
    }

    @Override
    public String visit(OpExpr expr) {
        if (expr instanceof MulDivExpr)
            return visit((MulDivExpr) expr);
        return visit((AddSubExpr) expr);
    }
}
