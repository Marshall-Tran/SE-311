package client.Visitor;

import client.Composite.*;

public interface Visitor {

    String visit(Expression expr);
    String visit(AddSubExpr expr);
    String visit(MulDivExpr expr);
    String visit(AtomExpr expr);
    String visit(OpExpr expr);

}
