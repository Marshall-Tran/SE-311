package client.Visitor;

import client.Composite.*;

public class CalcVisitor implements Visitor{

    @Override
    public String visit(Expression expr) {
        if (expr instanceof OpExpr)
            return visit((OpExpr) expr);
        return visit((AtomExpr) expr);
    }

    @Override
    public String visit(AddSubExpr expr) {
        Expression left = expr.getLeftChild();
        Expression right = expr.getRightChild();

        Float leftValue = Float.parseFloat(visit(left));
        Float rightValue = Float.parseFloat(visit(right));
        Float returnValue = null;

        switch (expr.getValue()) {

            case "+":
                returnValue = leftValue + rightValue;
                break;

            case "-":
                returnValue = leftValue - rightValue;
                break;
        }

        return returnValue.toString();
    }

    @Override
    public String visit(MulDivExpr expr) {
        Expression left = expr.getLeftChild();
        Expression right = expr.getRightChild();
        Float leftValue = Float.parseFloat(visit(left));
        Float rightValue = Float.parseFloat(visit(right));
        Float returnValue = null;

        switch (expr.getValue()) {

            case "/":
                //Handled in NextOp State, but just in case
                if (rightValue == 0)  {
                    returnValue = Float.NaN;
                    break;
                }
                returnValue = leftValue / rightValue;
                break;

            case "*":
                returnValue = leftValue * rightValue;
                break;
        }

        return returnValue.toString();
    }

    @Override
    public String visit(AtomExpr expr) {
        return expr.getValue();
    }

    @Override
    public String visit(OpExpr expr) {
        if (expr instanceof MulDivExpr)
            return visit((MulDivExpr) expr);
        return visit((AddSubExpr) expr);
    }
}