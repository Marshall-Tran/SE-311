package client.Composite;

import client.Visitor.*;


public class AtomExpr implements Expression {

    private String value;
    public AtomExpr(String value) {this.value = value;}

    @Override
    public String getValue() {
        return value;
    }

    @Override
    public void appendVal(String val) {
        value += val;
    }

    @Override
    public void addLeftChild(Expression left) {
        return;
    }

    @Override
    public void addRightChild(Expression right) {
        return;
    }

    @Override
    public Expression getLeftChild() {
        return null;
    }

    @Override
    public Expression getRightChild() {
        return null;
    }


    @Override
    public String accept(Visitor v) {
        return v.visit(this);

    }
}
