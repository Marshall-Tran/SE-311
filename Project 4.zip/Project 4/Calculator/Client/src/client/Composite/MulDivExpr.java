package client.Composite;

import client.Visitor.*;


public class MulDivExpr extends OpExpr {
    public MulDivExpr(String value) {
        super(value);
    }

    @Override
    public String accept(Visitor v) {
        return v.visit(this);
    }

}