package client.Composite;

import client.Visitor.*;


public interface Expression {
    public String getValue();

    public void appendVal(String val);

    public void addLeftChild(Expression left);
    public void addRightChild(Expression right);

    public Expression getLeftChild();

    public Expression getRightChild();

    public String accept(Visitor v);

}
