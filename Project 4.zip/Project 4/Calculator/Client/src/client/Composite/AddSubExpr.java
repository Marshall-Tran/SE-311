package client.Composite;

import client.Visitor.*;

public class AddSubExpr extends OpExpr {
    public AddSubExpr(String value) {
        super(value);
    }

    @Override
    public String accept(Visitor v) {
        return v.visit(this);
    }

}