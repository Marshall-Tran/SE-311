package client.Composite;

import client.Visitor.*;


public abstract class OpExpr implements Expression {
    protected String value;
    protected Expression exprLeft;
    protected Expression exprRight;

    public OpExpr(String value) {this.value = value;}
    @Override
    public void addLeftChild(Expression left) {
        this.exprLeft = left;
    }
    @Override
    public void addRightChild(Expression right) {
        this.exprRight = right;
    }

    @Override
    public Expression getLeftChild() {
        return exprLeft;
    }

    @Override
    public Expression getRightChild() {
        return exprRight;

    }

    @Override
    public String getValue() {
        return this.value;
    }

    @Override
    public void appendVal(String val) {

    }

    @Override
    public String accept(Visitor v) {
        return v.visit(this);
    }
}
