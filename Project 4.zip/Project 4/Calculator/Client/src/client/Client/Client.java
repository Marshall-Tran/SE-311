package client.Client;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class Client {
    public void sendToServer(String expr) throws IOException {
        Socket socket = new Socket("localhost", 8000);
        ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
        oos.writeObject(expr);
        oos.close();
        socket.close();
    }
}
