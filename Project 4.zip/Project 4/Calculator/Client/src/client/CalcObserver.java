package client;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import client.Composite.Expression;
import client.States.*;
import client.States.Error;
import client.Visitor.CalcVisitor;
import client.Visitor.PrintVisitor;
import client.Client.*;

public class CalcObserver implements ActionListener {
    private State currState;
    private CalcView view;

    public CalcObserver(){
        currState = new Start(null);
    }

    public void setCalculator(CalcView calc) { view = calc; }


    @Override
    public void actionPerformed(ActionEvent event) {
        String value = event.getActionCommand();
        currState = this.currState.nextState(event);
        boolean isError = currState instanceof Error;
        if(!isError){
            currState.constructTree(event);
        }
        updateDisplay();
    }

    public CalcView getView() {
        return this.view;
    }

    public void updateDisplay() {
        String display_text = "";

        if(currState instanceof Start){
            display_text = "";
        }

        if (currState instanceof Error) {
            display_text = "ERROR: C to Reset or continue the equation to Discard.";
        }

        if (currState instanceof Calculate) {
            Expression tree = currState.getTree();
            String result = tree.accept(new CalcVisitor());
            display_text +=  " " + " = " + result;
            String expr = tree.accept(new PrintVisitor()) + " = " + result;
            try {
                new Client().sendToServer(expr);

            } catch (IOException e){
                System.out.println("Error sending expression to Server :(");
            }
        }

        if (currState instanceof FirstOp) {
            display_text += " " + currState.getFirstOp().getValue();
        }

        if(currState instanceof NextOp){
            display_text += " " + currState.getTree().getValue();
        }

        if(currState instanceof WaitOp){
            display_text += " " + currState.getSecondOp().getValue();
        }

        view.updateResult(display_text);
    }
}
