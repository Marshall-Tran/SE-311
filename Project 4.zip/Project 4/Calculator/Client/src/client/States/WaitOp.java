package client.States;

import client.CalcObserver;
import client.Composite.AtomExpr;
import client.Composite.Expression;
import client.Composite.OpExpr;

import java.awt.event.ActionEvent;

public class WaitOp extends State {
    public WaitOp(State parent) {
        super(parent);
    }

    @Override
    public State nextState(ActionEvent event) {
        String value = event.getActionCommand();

        switch(value){
            case "0":
            case "1":
            case "2":
            case "3":
            case "4":
            case "5":
            case "6":
            case "7":
            case "8":
            case "9":
                    return(new WaitOp(this));

            case "+":
            case "-":
            case "*":
            case "/":
                return(new NextOp(this));

            case"=":
                return(new Calculate(this));

            default:
                return(new Start(null));
        }
    }

    @Override
    public void constructTree(ActionEvent event) {
        String value = event.getActionCommand();
        Expression tempPointer = tree.getRightChild();
        if(tempPointer == null){
            tree.addRightChild(new AtomExpr(value));
            secondOp = (AtomExpr) tree.getRightChild();
        } else if(tempPointer instanceof AtomExpr) {
            secondOp.appendVal(value);
        } else {
            if(secondOp == null){
                tempPointer.addRightChild(new AtomExpr(value));
                secondOp = (AtomExpr) tempPointer.getRightChild();
            } else {
                secondOp.appendVal(value);
            }
        }
    }
}

