package client.States;

import client.CalcObserver;

import java.awt.event.ActionEvent;

public class Calculate extends State {
    public Calculate(State parent) {
        super(parent);
    }

    @Override
    public State nextState(ActionEvent event) {
        String value = event.getActionCommand();

        switch (value) {
            case "0":
            case "1":
            case "2":
            case "3":
            case "4":
            case "5":
            case "6":
            case "7":
            case "8":
            case "9":
                return(new FirstOp(this));

            default:
                return(new Start(null));
        }
    }

    @Override
    public void constructTree(ActionEvent event) {
        return;
    }
}
