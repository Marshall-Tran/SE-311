package client.States;

import client.CalcObserver;
import client.Composite.AtomExpr;

import java.awt.event.ActionEvent;

public class FirstOp extends State {

    public FirstOp(State parent) {
        super(parent);
    }

    @Override
    public State nextState(ActionEvent event) {
        String value = event.getActionCommand();

        switch(value){

            case "0":
            case "1":
            case "2":
            case "3":
            case "4":
            case "5":
            case "6":
            case "7":
            case "8":
            case "9":
                return(new FirstOp(this));

            case "+":
            case "-":
            case "*":
            case "/":
                return(new NextOp(this));

            case "C":
                return(new Start(null));

            default:
                return(new Error(this));
        }

    }

    @Override
    public void constructTree(ActionEvent event) {
        String value = event.getActionCommand();
        if(firstOp == null){
            firstOp = new AtomExpr(value);
        } else {
            firstOp.appendVal(value);
        }
    }
}

