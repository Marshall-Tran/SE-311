package client.States;

import client.CalcObserver;
import client.Composite.*;

import java.awt.event.ActionEvent;

public class NextOp extends State {

    public NextOp(State parent) {
        super(parent);
    }

    @Override
    public State nextState(ActionEvent event) {
        String value = event.getActionCommand();

        switch(value){
            case "0":
                if(tree.getValue() == "/") {
                    return(new Error(this));
                }
            case "1":
            case "2":
            case "3":
            case "4":
            case "5":
            case "6":
            case "7":
            case "8":
            case "9":
                return(new WaitOp(this));

            case "C":
                return(new Start(null));

            default:
                return(new Error(this));
        }

    }


    @Override
    public void constructTree(ActionEvent event) {
        String value = event.getActionCommand();
        OpExpr tempRoot = switch (value) {
            case "+", "-" -> new AddSubExpr(value);
            case "*", "/" -> new MulDivExpr(value);
            default -> null;
        };

        if (tree == null) {
            tempRoot.addLeftChild(firstOp);
            tree = tempRoot;
        } else {
            if(checkSameNode(tempRoot) || (tree instanceof MulDivExpr && tempRoot instanceof AddSubExpr)){
                tempRoot.addLeftChild(tree);
                tree = tempRoot;
            } else {
                Expression subRight = tree.getRightChild();
                tempRoot.addLeftChild(subRight);
                tree.addRightChild(tempRoot);
            }
        }
        firstOp = null;
        secondOp = null;
    }

    private boolean checkSameNode(OpExpr currNode){
        return (tree instanceof AddSubExpr && currNode instanceof AddSubExpr) || (tree instanceof MulDivExpr && currNode instanceof MulDivExpr);
    }
}