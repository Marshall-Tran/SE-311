package client.States;

import java.awt.event.ActionEvent;
import client.CalcObserver;
import client.Composite.AtomExpr;
import client.Composite.Expression;

public abstract class State {
    private State parent;
    protected Expression tree = null;
    protected AtomExpr firstOp = null;
    protected AtomExpr secondOp = null;
    public State(State parent){
        this.parent = parent;
        if (parent != null && !(parent instanceof Calculate)) {
            this.tree = parent.tree;
            this.firstOp = parent.firstOp;
            this.secondOp = parent.secondOp;
        }
    }

    public abstract State nextState(ActionEvent event);
    public State getParent(){
        return parent;
    }

    public Expression getTree(){
        return tree;
    }

    public Expression getFirstOp (){
        return firstOp;
    }

    public Expression getSecondOp (){
        return secondOp;
    }

    public abstract void constructTree(ActionEvent event);

}

