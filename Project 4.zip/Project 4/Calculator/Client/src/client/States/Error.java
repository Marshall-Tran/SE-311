package client.States;

import client.CalcObserver;

import java.awt.event.ActionEvent;
import java.nio.file.FileStore;

public class Error extends State {

    public Error(State parent) {
        super(parent);
    }

    @Override
    public State nextState(ActionEvent event) {
        String value = event.getActionCommand();
        State parentState = this.getParent();

        //Update view to Error Prompt: Discard or Reset
        //Discard = Previous state
        //C to reset
        //Handle invalid inputs and transition to the next state if input is valid.

        if(parentState instanceof FirstOp){
            switch(value){

                case "0":
                case "1":
                case "2":
                case "3":
                case "4":
                case "5":
                case "6":
                case "7":
                case "8":
                case "9":
                    return(new FirstOp(parentState));

                case "+":
                case "-":
                case "*":
                case "/":
                    return(new NextOp(parentState));

                case "C":
                    return(new Start(null));

                default:
                    return(new Error(parentState));
            }
        }
        if(parentState instanceof NextOp){
            switch(value){

                case "0":
                    if(tree.getValue() == "/") {
                        return(new Error(this));
                    }
                case "1":
                case "2":
                case "3":
                case "4":
                case "5":
                case "6":
                case "7":
                case "8":
                case "9":
                    return (new WaitOp(parentState));

                case "C":
                    return(new Start(null));

                default:
                    return(new Error(parentState));

            }
        }
        return (new Error(parentState));
    }

    @Override
    public void constructTree(ActionEvent event) {
        return;
    }
}

