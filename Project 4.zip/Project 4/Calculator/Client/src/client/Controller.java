package client;

public class Controller {
    public static void main(String[] args) {
        CalcView calculator = new CalcView();
        CalcObserver handler = new CalcObserver();
        calculator.attachListener(handler);
        handler.setCalculator(calculator);
    }
}