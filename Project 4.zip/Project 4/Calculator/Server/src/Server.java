import java.io.*;
import java.net.*;
import java.util.ArrayList;

public class Server {
    public static void main(String[] args) throws IOException, CloneNotSupportedException {
        ServerSocket server = new ServerSocket(8000);
        ArrayList<String> storage = new ArrayList<String>();


        while (true){
            Socket client = server.accept();
            RequestHandler rh = new RequestHandler(client, storage);
            rh.start();
        }
    }
}