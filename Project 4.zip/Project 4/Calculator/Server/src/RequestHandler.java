import javax.sound.sampled.Line;
import java.io.*;
import java.net.*;
import java.util.ArrayList;

public class RequestHandler extends Thread {
    private Socket clientSocket;
    private ArrayList<String> storage;

    public RequestHandler(Socket cSocket, ArrayList<String> storage){
        clientSocket = cSocket;
        this.storage = storage;
    }

    public void run(){
        try {
            ObjectInputStream ois = new ObjectInputStream(clientSocket.getInputStream());
           String expr = (String) ois.readObject();
           storage.add(expr);

           System.out.println("Total number of successful equations: " + storage.size());

           for(String exprString: storage){
               System.out.println(" " + exprString + "\n");
           }

            clientSocket.close();

        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}