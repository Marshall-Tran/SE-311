Marshall Tran
SE 311
Assignment 3



Notes:

Composite Pattern:
Expression - Component Interface
AddSubExpr - Composite Class
MulDivExpr - Composite Class
OpExpr - Composite Abstract Class
AtomExpr - Leaf

Visitor Pattern:
Visitor - Interface Visitor
CalcVisitor - Concrete Visitor
PrintVisitor - Concrete Visitor

Observer Pattern:
CalcObserver - Concrete Observer
CalcView - Concrete Subject

State Pattern:
State - State Abstract Class
Start - Concrete State
FirstOp - Concrete State
NextOp - Concrete State
WaitOp - Concrete State
Calculate - Concrete State
Error - Concrete State



How to run: Run Controller.java class to start the client and calculator. Run Server.java class to start the server. If you have trouble running both, open the the two src folders in separate windows. (Katrina should know how to successfully run them. Please let me know if you have trouble running it.)

Configuration: No configs except the Client and Server ports in the code.